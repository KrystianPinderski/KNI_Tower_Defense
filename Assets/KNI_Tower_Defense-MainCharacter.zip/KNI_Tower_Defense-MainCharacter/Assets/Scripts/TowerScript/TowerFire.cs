﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerFire : Tower {

	// Use this for initialization
	 public override void Start () {
        base.Start();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    //public override void OnTriggerEnter(Collider other)
    //{
    //    base.OnTriggerEnter(other);
    //}

    //public override IEnumerator ShowRedModel(GameObject tmp)
    //{
    //    return base.ShowRedModel(tmp);
    //}
}
